#include <stdio.h>
#include <stdlib.h>

/*
Program to implement a text cipher
******************************************************************
* Author       Deptartment            Date             Notes
******************************************************************
Ling Fei Zhang Comp. Sc               March 15th      Initial version
*/


// create main method to write the program
int main(int argc, char*argv[]){


//check if the number of given arguments is invalid
if (argc != 4)
{	printf("Usage : ./cipher [-e|-d] <key> <MESSAGE>\n");
exit(1);
}

//check if given option is invalid
if ((argv[1][1] != 101 && argv[1][1] != 100) || argv[1][0] != 45)
{printf ("Error %s is not a valid option\n", argv[1]);
exit(1);
}


//check if given key is invalid
if (!(argv[2][0] == 49 && argv[2][1] == 48) && !((argv[2][0] >= 50 && argv[2][0] <= 57) && argv[2][1] == 0))
{printf("Error %s is not a valid key\n", argv[2]);
exit(1);}



//in the case that the script is called with decryption
//print a new line and exit the script with code 0
if (argv[1][0] == 45 && argv[1][1] == 100){printf("\n");
exit(0);}


//create a counter variable to count the length of the string
int counter = 0;

//uses a while loop to count the length of string
while(argv[3][counter] != 0){counter++;}

//create a variable to have the integer representation of the given key
int key = argv[2][0] - 48;
if (key == 1){key = 10;}


//create a variable to store the length of one full cycle
//if key is 5, then length will have value 8 since it is at the 8th position that 
//another letter will be at the first level
int length = 2*(key-1);


//if the length of the string is smaller than the key, simply print the string and exit with 0
if (counter <= key){printf("%s\n",argv[3]);
exit(0);}


//if the given string is empty, simply print a new line and exit with 0
if(argv[3][0] == 34 && argv[3][1] == 34){printf("\n");
exit(0);}


//iterate through each level
for (int i =0;i< key;i++){


//iterate through each index of the string
for (int j = 0; j <counter;j++){

//if the first level is being evaluated
//we know which indices should be printed if we know the length of a full cycle
if (i==0 && j%length == 0){putchar(argv[3][j]);}

//if the last level is being evaluated
//this step is skipped for now, and being done at the end
else if (i==key-1){
continue;}

//if the intermediate levels are being evaluated
else{
if ((j+i)%length==0 && j < counter){putchar(argv[3][j]);}
if ((j-i)%length == 0 && j<counter)
{putchar(argv[3][j]);} 
}
}
}


//evaluating the last level
int tmp = key-1;
while(tmp < counter){
putchar(argv[3][tmp]);
tmp += length;}

//end the program with a new line character and exit with 0
printf("\n");
exit(0);
}
