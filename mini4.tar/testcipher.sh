#!/bin/bash


#check if there is indeed no argument given to the script
if [ $# -ne 0 ]
then
echo "Usage: ./testcipher.sh"
exit 1
fi

#check if the file is not in current directory
if [ ! -f cipher.c ]
then
echo "cipher.c is not in the current directory"
exit 1
fi

#compile the cipher program
gcc -o cipher cipher.c


#start testing
#tests calling ./cipher
echo "--------------------------------------------"
echo "Starting test for ./cipher"
echo "Output from ./cipher and its exit code" 
./cipher
echo $?
echo "Expected output:"
echo "Usage : ./cipher [-e|-d] <key> <MESSAGE>"
echo "1"

#tests calling with wrong option
echo "-------------------------------------------"
echo "Starting test for ./cipher -k 5 THISISASECRETMESSAGE"
echo "Output from ./cipher -k 5 THISISASECRETMESSAGE and its exit code"
./cipher -k 5 THISISASECRETMESSAGE
echo $?
echo "Expected output:"
echo "Error -k is not a valid option"
echo "1"



#tests calling with wrong key
echo "-------------------------------------------"
echo "Starting test for ./cipher -e 4.r HELLOTHERE"
echo "Output from ./cipher -e 4.r HELLOTHERE and its exit code"
./cipher -e 4.r HELLOTHERE
echo $?
echo "Expected output:"
echo "Error 4.r is not a valid key"
echo "1"


#tests calling with wrong key
echo "-------------------------------------------"
echo "Starting test for ./cipher -e 11 HELLOTHERE"
echo "Output from ./cipher -e 11 HELLOTHERE and its exit code"
./cipher -e 11 HELLOTHERE
echo $?
echo "Expected output:"
echo "Error 11 is not a valid key"
echo "1"

#tests calling with wrong key
echo "------------------------------------------"
echo "Starting test for ./cipher -e 1 HELLOTHERE"
echo "Output from ./cipher -e 1 HELLOTHERE and its exit code"
./cipher -e 1 HELLOTHERE
echo $?
echo "Expected output:"
echo "Error 1 is not a valid key"
echo "1"



#tests calling with decryption
echo "------------------------------------------"
echo "Starting test for ./cipher -d 4 HELLOTHERE"
echo "Output from ./cipher -d 4 HELLOTHERE and its exit code"
./cipher -d 4 HELLOTHERE
echo $?
echo "Expected output:"
echo ""
echo "0"

#tests calling with empty string
echo "------------------------------------------"
echo "Starting test for ./cipher -e 5 """
echo "Output from ./cipher -e 5 "" and its exit code"
./cipher -e 5 ""
echo $?
echo "Expected output:"
echo ""
echo "0"


#tests code with given example
echo "------------------------------------------"
echo "Starting test for ./cipher -e 5 THISISASECRETMESSAGE"
echo "Output from ./cipher -e 5 THISISASECRETMESSAGE and its exit code"
./cipher -e 5 THISISASECRETMESSAGE
echo $?
echo "Expected output:"
echo "TESHSCSAIAREGSSEMEIT"
echo "0"

#tests code with given example
echo "------------------------------------------"
echo "Starting test for ./cipher -e 3 THISISASECRETMESSAGE"
echo "Output from ./cipher -e 3 THISISASECRETMESSAGE and its exit code"
./cipher -e 3 THISISASECRETMESSAGE
echo $?
echo "Expected output:"
echo "TIETSHSSSCEMSAEIAREG"
echo "0"


#tests with another example
echo "-----------------------------------------"
echo "Starting test for ./cipher -e 5 HELLOTHERE"
echo "Output from ./cipher -e 5 HELLOTHERE and its exit code"
./cipher -e 5 HELLOTHERE
echo $?
echo "Expected output:"
echo "HREEELHLTO"
echo "0"



